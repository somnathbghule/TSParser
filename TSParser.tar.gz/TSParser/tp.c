#include "tp.h"
#include "pat.h"
#include "eit.h"

static const char *mfile;

int fd = 0;

unsigned char *getsyncbyte(unsigned char *buf){
	//later
	return buf;
}

void tableParser(unsigned char *section, unsigned char payload_unit_start_indicator, int size, int table){
	switch(table){
	case PAT:
		patParser(section,payload_unit_start_indicator,size);
		break;
	case CAT:
		break;
	case TSDT:
		break;
	case PS:
		break;
	case PMT:
		break;
	case NIT:
		nitParser(section,payload_unit_start_indicator,size);
		break;
	case SDT:
		sdtParser(section,payload_unit_start_indicator,size);
		break;
	case BAT:
		break;
	case EIT:
		eitParser(section,payload_unit_start_indicator,size);
		break;
	case RST:
		break;
	case TDT:
		break;
	case TOT:
		break;
	case DIT:
		break;
	case SIT:
		break;
	case ST:
	default:
		break;
	}
}

int checkPacket(unsigned short pid,int table) {
	switch(table){
	case PAT:
		return pid==0x0000?1:0;
	case CAT:
		return pid==0x0001?1:0;
	case TSDT:
		return pid==0x0002?1:0;
	case PS:
		break;
	case PMT:
		break;
	case NIT:
		return pid==0x0010?1:0;
	case SDT:
		return pid==0x0011?1:0;
		break;
	case BAT:
		break;
	case EIT:
		return pid==0x0012?1:0;
	case RST:
		return pid==0x0013?1:0;
	case TDT:
		break;
	case TOT:
		break;
	case DIT:
		return pid==0x001E?1:0;
	case SIT:
		return pid==0x001F?1:0;
	case ST:
		break;
	default:
		break;
	}
	return 0;
}

int transport_packet (unsigned char *current_packet,int table) {
	unsigned short pid;
	memcpy(&pid, current_packet + 1, 2);
	pid = ntohs(pid);
	pid = pid & 0x1fff;

	if(!checkPacket(pid,table)){
		return PID_NO_MATCH;
	}
	if (current_packet[0] != 0x47) {
		return PID_NO_SYNC;
	}
	fprintf(stderr,"-----------------New Packet----------------\n");

	fprintf(stderr,"sync_byte (8 bits) : %u (0x%x)\n",current_packet[0],current_packet[0]);

	unsigned char transport_error_indicator = (current_packet[1] >> 7) & 0x01;
	fprintf(stderr,"transport_error_indicator (1 bit) : %u\n",transport_error_indicator);

	unsigned char payload_unit_start_indicator = (current_packet[1] >> 6) & 0x01;
	fprintf(stderr,"payload_unit_start_indicator (1 bit) : %u\n",payload_unit_start_indicator);

	unsigned char transport_priority = (current_packet[1] >> 5) & 0x01;
	fprintf(stderr,"transport_priority (1 bit) : %u\n",transport_priority);

	fprintf(stderr,"pid (13 bits) : %u (0x%04x)\n",pid,pid);

	unsigned char transport_scrambling_control = (current_packet[3] >>6 ) & 0x03;
	fprintf(stderr,"transport_scrambling_control (2 bits) : %u (0x%x)\n",transport_scrambling_control,transport_scrambling_control);

	unsigned char adaptation_field_control = (current_packet[3] >>4 ) & 0x03;
	fprintf(stderr,"adaptation_field_control (2 bits) : %u (0x%x)\n",adaptation_field_control,adaptation_field_control);

	unsigned char continuity_counter = current_packet[3] & 0x0F;
	fprintf(stderr,"continuity_counter (4 bits) : %u (0x%x)\n",continuity_counter,continuity_counter);

    int ts_header_size = 4;
	unsigned char adaptation_field_length = 0;
	if(adaptation_field_control == 0) {
		return PID_ADAPT_0;
	}else if(adaptation_field_control == 2) {
		adaptation_field_length = current_packet[4];
		fprintf(stderr,"adaptation_field_length (8 bits) : %u (0x%x)\n",adaptation_field_length,adaptation_field_length);
		//adaptation_field();
		return PID_ADAPT_2;
	}else if(adaptation_field_control == 3) {
		adaptation_field_length = current_packet[4];
		ts_header_size += adaptation_field_length +1;
		fprintf(stderr,"adaptation_field_length (8 bits) : %u (0x%x)\n",adaptation_field_length,adaptation_field_length);
		//adaptation_field();
	}

	tableParser(current_packet+ts_header_size,payload_unit_start_indicator,TS_PACKET_SIZE-ts_header_size,table);
	return PID_PACKET_REQD;
}

void verbosePacket(int table) {
	unsigned char buf[188];
	fd = open(mfile,O_RDONLY);
	while(read(fd,buf,TS_PACKET_SIZE)>0){
		unsigned char *tpBegin = getsyncbyte(buf);
		if(transport_packet(tpBegin,table) == PID_PACKET_REQD) {
			//got
			break;
		}
	}
	close(fd);
}

void setTS(char *file) {
	mfile = file;
}
