#ifndef TP_H_
#define TP_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include "descriptor.h"
/*
Table					PID value
PAT						0x0000
CAT						0x0001
TSDT					0x0002
reserved				0x0003 to 0x000F
NIT, ST					0x0010
SDT, BAT, ST			0x0011
EIT, ST					0x0012
RST, ST					0x0013
TDT, TOT, ST			0x0014
network synchronization	0x0015
reserved for future use	0x0016 to 0x001B
inband signalling		0x001C
measurement				0x001D
DIT						0x001E
SIT						0x001F
*/
/*
table_id			Description
0x00			program_association_section
0x01			conditional_access_section
0x02			program_map_section
0x03			transport_stream_description_section
0x04 to 0x3F	reserved
0x40			network_information_section - actual_network
0x41			network_information_section - other_network
0x42			service_description_section - actual_transport_stream
0x43 to 0x45	reserved for future use
0x46			service_description_section - other_transport_stream
0x47 to 0x49	reserved for future use
0x4A			bouquet_association_section
0x4B to 0x4D	reserved for future use
0x4E			event_information_section - actual_transport_stream, present/following
0x4F			event_information_section - other_transport_stream, present/following
0x50 to 0x5F	event_information_section - actual_transport_stream, schedule
0x60 to 0x6F	event_information_section - other_transport_stream, schedule
0x70			time_date_section
0x71			running_status_section
0x72			stuffing_section
0x73			time_offset_section
0x74 to 0x7D	reserved for future use
0x7E			discontinuity_information_section
0x7F			selection_information_section
0x80 to 0xFE	user defined
0xFF			reserved
*/

enum sections{
	ALL = 0,
	PAT = 1,			//0x0000
	CAT = 2,			//0x0001
	TSDT = 3,			//0x0002
	PS = 4,
	PMT = 5,			//0x10 to 0x1FFE
	NIT = 6,			//0x0010
	SDT = 7,			//0x0011
	BAT = 8,			//0x0011
	EIT = 9,			//0x0012
	RST = 10,			//0x0013
	TDT = 11,			//0x0014
	TOT = 12,			//0x0014
	DIT = 13,			//0x001E
	SIT = 14,			//0x001F
	ST = 15
};

enum checkPacket {
	PID_NO_MATCH = 0,
	PID_PACKET_REQD,
	PID_NO_SYNC,
	PID_ADAPT_0,
	PID_ADAPT_2,
};

#define TS_PACKET_SIZE 188

void verbosePacket(int table);

void setTS(char *file);

#endif /* TP_H_ */
